// console.log("Hello World");
// function sayHello()
// {
//     console.log("Hello friends");
// }
// sayHello();
// function add(a,b)
// {
//     return a+b;
// }
// function sub(a,b)
// {
//     return a-b;
// }
// function mul(a,b)
// {
//     return a*b;
// }
// function div(a,b)
// {
//     if(b===0)
//     throw new Error("cannot divide using zero");
//     return a/b;
// } 
// function sayGoodmorning(name)
// {
//     // return "Good Morning"+name;
//      return `Good Morning ${name}`;
// }
// function sayGoodafternoon(name)
// {
//      return `Good Afternoon ${name}`;
// }
// function sayGoodevening(name)
// {
//      return `Good Evening ${name}`;
// }

// class Person
// {
//     constructor()
//     {
//         this.firstname="";
//         this.lastname="";
//     }
//     getFullname()
//     {
//         return `${this.firstname} ${this.lastname}`;
//     }
// }
// var a=5;b=3;
// var res=mul(a,b);
// console.log(`Product is ${res}`);

// var person=new Person()
// person.firstname="Vishal";
// person.lastname="Barde";
// var fullname=person.getFullname();

// var greeting=sayGoodafternoon(fullname);
// console.log(greeting);

var Person=require("./person");
var Calculator=require("./calculator");            //Calulator is json object
// var Greeting=require("./greeting");
// var sayGaf=require("./greeting").sayGoodafternoon;
// var {sayGoodafternoon,sayGoodevening}=require("./greeting");
var {getGoodafternoon}=require("./greeting");

var a=5;b=5;
var res=Calculator.mul(a,b);
console.log(`Product is ${res}`);

var person=new Person()
person.firstname="Vishal";
person.lastname="Barde";
var fullname=person.getFullname();
// var greeting=sayGoodafternoon(fullname);
// var greeting=Greeting.sayGoodafternoon(fullname);
// var greeting=sayGaf(fullname);
var greeting=getGoodafternoon(fullname);
console.log(greeting);