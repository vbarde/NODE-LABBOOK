function add(a,b)
{
    return a+b;
}
function sub(a,b)
{
    return a-b;
}
function mul(a,b)
{
    return a*b;
}
function div(a,b)
{
    if(b===0)
    throw new Error("cannot divide using zero");
    return a/b;
} 
//for exporting all functions
module.exports={
    add,sub,mul,div
}


//or
//exports.add=function(a,b)
// {
//     return a+b;
// }
//exports.sub=function(a,b)
// {
//     return a-b;
// }
//exports.mul=function(a,b)
// {
//     return a*b;
// }
//exports.div=function(a,b)
// {
//     return a/b;
// }