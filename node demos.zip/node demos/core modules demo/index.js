var buff= Buffer.from("Sample data");
console.log(buff.toString());
// console.log(buff);
var b=Buffer.alloc(100);
var noOfBytesWritten= b.write("This is sample data");
console.log("bytes written:"+noOfBytesWritten);
 console.log(b.toString());