
function sayHello(name,callback)
{
    //Time consuming ,long running operation here
    setTimeout(()=>
    {
        callback("Hello" +name);
    },3000);
}
console.log("calling sayHello()");
sayHello("Sonu",function(result)
{
    console.log(result);        
});
console.log("completed");
