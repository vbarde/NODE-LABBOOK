var EventEmitter=require("events").EventEmitter;
var ee=new EventEmitter();
var timer;
ee.once("start",(startPos)=>{
    var i=startPos;
    console.log("starting timer");
    timer=setInterval(()=>{
        console.log(i);
        i++;
        
    },500);
});
ee.on("stop",()=>{
    console.log("Stopping timer");
    clearInterval(timer);
})

ee.emit("start",100);
setTimeout(()=>
{
    ee.emit("stop");
    ee.emit("start",50);  //cannot raise start event again
},10000);