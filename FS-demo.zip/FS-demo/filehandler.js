// asynchronous way -callback
var fs = require("fs");
var path = require("path");
exports.writeContent = (filename, content) => {
    var filePath = path.resolve(__dirname, "myfiles", filename);
    fs.open(filePath, "w", (err, fd) => {
        if (err) {
            console.log("Failed to open file");
            return;
        }
        fs.write(fd, Buffer.from(content), (err, noOfBytes, buff) => {
            if (err) {
                console.log("failed to write content");
                return;
            }
            console.log("successfully written the content");
            fs.close(fd, (err) => {
                if (err) {
                    console.log("errror in closing file");
                    return;
                }
                console.log("file closed");
            })
        })
    })
}
exports.readContent = (filename) => {
    var filePath = path.resolve(__dirname, "myfiles", filename);
    fs.open(filePath, "r", (err, fd) => {
        if (err) {
            console.log("Failed to open file");
            return;
        }
        var buffer = Buffer.alloc(100);
        fs.read(fd, buffer, 0, 100,0, (err, bytesRead, buff) => {
            if (err) {
                console.log("failed to read");
                return;
            }
            console.log(buff.toString());

            fs.close(fd, (err) => {
                console.log("FILE CLOSED");
            })
        })
    });
}
//synchronous way-return
exports.writeContentSync=(filename,content)=>{
    var filePath = path.resolve(__dirname, "myfiles", filename);
    var fd=fs.openSync(filePath,"w")
    if(!fd)
    {
        console.log("failed to open file");
        return; 
    }
    var bytes=fs.writeSync(fd,Buffer.from(content));
    console.log("file written sucessfully");
    fs.closeSync(fd);

}
exports.readContentSync=(filename)=>{
    var filePath = path.resolve(__dirname, "myfiles", filename);
    var fd=fs.openSync(filePath,"r");
    if(!fd)
    {
        console.log("failed to open file");
        return; 
    }
    var buffer=Buffer.alloc(100);
    var bytes=fs.readSync(fd,buffer,0,100,0);
    console.log(buffer.toString());
    fs.closeSync(fd);

}

exports.writeFileContent=(filename,content)=>{
var filePath=path.resolve(__dirname,"myfiles",filename);
fs.writeFile(filePath,content,(err)=>{
    if(err)
    {
        console.log("Error in writing file");
        return;
    }
    console.log("written successfully");
})
}
exports.readFileContent=(filename)=>{
    var filePath=path.resolve(__dirname,"myfiles",filename);
    fs.readFile(filePath,{encoding:"utf-8"},(err,data)=>{
        if(err)
        {
            console.log("Error in reading file");
            return;
        }
        console.log("data");
    })
    }

