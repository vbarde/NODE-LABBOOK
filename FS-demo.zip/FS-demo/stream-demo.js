//to handle large amount of data from server

var fs=require("fs");
var path=require("path");

exports.writeToFileStream=(filename,content)=>{
    var filePath=path.resolve(__dirname,"myfiles",filename);
    var stream=fs.createWriteStream(filePath,{encoding:"utf-8"});
    stream.write(content);
    stream.close();
}
exports.readFromFileStream=(filename)=>{
    var filePath=path.resolve(__dirname,"myfiles",filename);
    var stream=fs.createReadStream(filePath,{encoding:"utf-8"});
    var content="";   //all chunk of data stored here
    stream.on("data",(chunk)=>{    
        content+=chunk;
        // content+=chunk.length;
    });   //event-name is data
    stream.on("end",()=>{
        console.log("Streaming completed");
        console.log(content);
        stream.close();
    })
}