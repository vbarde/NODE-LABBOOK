//using asychronous
// var {writeContent,readContent}=require("./filehandler");
// var data="Hello,how are u"
// var filename="greet.txt";
// writeContent(filename,data);
// readContent(filename);

//using synchronous
// var {writeContentSync, readContentSync}=require("./filehandler");
// var data="Hello,how are u"
// var filename="greet2.txt";
// writeContentSync(filename,data);
// readContentSync(filename);

// var {writeFileContent,readFileContent}=require("./filehandler");
//  var data="Hello,how are u"
//  var filename="greet3.txt";
// writeFileContent(filename,data);
// readFileContent(filename);

// to check stats of file
// var path = require("path");
// var fs = require("fs");
// var filename="greet3.txt";
// var filePath=path.resolve(__dirname,"myfiles",filename);
// fs.stat(filePath,(err,stats)=>{
// console.log(stats);
// })

//use listener to watch file
// var path = require("path");
// var fs = require("fs");
// var filename="greet3.txt";
// var filePath=path.resolve(__dirname,"myfiles",filename);
// fs.watchFile(filePath,(current,prev)=>{
// //   console.log(prev.mtime+""+current.mtime);
//   console.log(prev.size+"--"+current.size);
// })

//stream
 var path = require("path");
 var fs = require("fs");
 var data="Hello,how are u vishal"
 var filename="data.txt";
var filePath=path.resolve(__dirname,"myfiles",filename);
var {writeToFileStream,readFromFileStream}=require("./stream-demo");
writeToFileStream(filename,data);
readFromFileStream(filename);

