var http = require("http");
var {requestHandler}=require("./request-handler");
var server = http.createServer(requestHandler);
server.listen(5000, (err) => {
    if (err) {
        console.log("couldnt load server");
        return;
    }
    console.log("Server started in port 5000");
})